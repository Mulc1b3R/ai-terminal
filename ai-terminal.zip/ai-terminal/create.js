const fs = require('fs');
const request = require('request');
const { createWriteStream } = require('fs');
const AdmZip = require('adm-zip');
require('dotenv').config();

const downloadZipAndUnzip = (url, outputPath) => {
    // Ensure output directory exists
    if (!fs.existsSync(outputPath)) {
        fs.mkdirSync(outputPath, { recursive: true });
    }

    const zipFilePath = `${outputPath}/Ai-Terminal.zip`;
    const zipOutputPath = outputPath;

    // Download the zip file from the URL
    request(url)
        .pipe(createWriteStream(zipFilePath))
        .on('close', () => {
            // Unzip the downloaded file
            const zip = new AdmZip(zipFilePath);
            zip.extractAllTo(zipOutputPath, true);

            console.log('Ai-Terminal-seed was created successfully!');
            fs.unlinkSync(zipFilePath); // Remove the downloaded zip file
        });
};

const targetUrl = process.env.TARGET_URL; // Load targetUrl from .env file
const outputFolder = './output'; // Output folder where the zip file will be saved and unpacked

downloadZipAndUnzip(targetUrl, outputFolder);